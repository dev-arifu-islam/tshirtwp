<?php
$addons = $GLOBALS['addons'];
?>
<button type="button" class="btn btn-default hidden-xs btn-sm btn-desktop" onclick="design.selectAll()">
	<i class="glyph-icon flaticon-folder flaticon-14"></i><small><?php echo $addons->__('addon_select_all_button_title'); ?></small>
</button>